class Product < ApplicationRecord
	has_many :inventories
end
