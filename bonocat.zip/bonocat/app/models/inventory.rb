class Inventory < ApplicationRecord
  belongs_to :product
end
