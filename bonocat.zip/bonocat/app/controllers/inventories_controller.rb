class InventoriesController < ApplicationController
end
