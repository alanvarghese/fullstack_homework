class CreateProducts < ActiveRecord::Migration[5.1]
  def change
    create_table :products do |t|
      t.integer :product_id
      t.text :product_name
      t.text :product_image
      t.text :product_description

      t.timestamps
    end
  end
end
